<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    <h2>Add Student</h2>

    <form method="POST">

        <div class="mb-3">
            <label>Name</label><input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Course</label><input type="text" name="course" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Year Level</label><input type="text" name="year_level" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Section</label><input type="text" name="section" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
                <option>Male</option>
                <option>Female</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Address</label><textarea name="address" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label>Phone Number</label><input type="text" name="phone" class="form-control" required>
        </div>

        <button class="btn btn-outline-primary" name="save">Save</button>
        <a href="main.php" class="btn btn-outline-dark">Back</a>
    </form>

    <?php
    if (isset($_POST['save'])) {
        $stmt = $conn->prepare("INSERT INTO students (name, course, year_level, section, gender, address, phone) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $_POST['name'], $_POST['course'], $_POST['year_level'], $_POST['section'], $_POST['gender'], $_POST['address'], $_POST['phone']);
        $stmt->execute();
        echo "<script>location.href='main.php';</script>";
    }
    ?>

</body>
</html>