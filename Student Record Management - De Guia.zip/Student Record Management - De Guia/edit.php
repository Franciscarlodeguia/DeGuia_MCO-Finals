<?php
include 'db_connect.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM students WHERE id=$id");
$student = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student Info Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    <h2>Edit Student</h2>

    <form method="POST">

        <div class="mb-3">
            <label>Name</label><input type="text" name="name" value="<?= $student['name'] ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Course</label><input type="text" name="course" value="<?= $student['course'] ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Year Level</label><input type="text" name="year_level" value="<?= $student['year_level'] ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Section</label><input type="text" name="section" value="<?= $student['section'] ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
                <option <?= $student['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                <option <?= $student['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Address</label><textarea name="address" class="form-control" required><?= $student['address'] ?></textarea>
        </div>

        <div class="mb-3">
            <label>Phone Number</label><input type="text" name="phone" value="<?= $student['phone'] ?>" class="form-control" required>
        </div>
        
        <button class="btn btn-outline-primary" name="update">Update</button>
        <a href="main.php" class="btn btn-outline-dark">Back</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $stmt = $conn->prepare("UPDATE students SET name=?, course=?, year_level=?, section=?, gender=?, address=?, phone=? WHERE id=?");
        $stmt->bind_param("sssssssi", $_POST['name'], $_POST['course'], $_POST['year_level'], $_POST['section'], $_POST['gender'], $_POST['address'], $_POST['phone'], $id);
        $stmt->execute();
        echo "<script>location.href='main.php';</script>";
    }
    ?>
</body>
</html>
