<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Record Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    <h2 class="fs-1 fw-bold mb-3">Student Records</h2>

    <div class="row mb-3 align-items-center">
        <div class="col-sm-8 mb-2 mb-sm-0">
            <input type="text" id="searchInput" onkeyup="searchTable()" class="form-control" placeholder="Search...">
        </div>
        <div class="col-sm-4 text-sm-end">
            <a href="add.php" class="btn btn-outline-dark w-80 w-sm-auto">Add Student</a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th>ID</th><th>Name</th><th>Course</th><th>Year</th>
                    <th>Section</th><th>Gender</th><th>Address</th><th>Phone</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM students ORDER BY name ASC");
                while($row = $result->fetch_assoc()):
                ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['course'] ?></td>
                    <td><?= $row['year_level'] ?></td>
                    <td><?= $row['section'] ?></td>
                    <td><?= $row['gender'] ?></td>
                    <td><?= $row['address'] ?></td>
                    <td><?= $row['phone'] ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-outline-info btn-sm mb-1">Edit</a>
                        <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-outline-danger btn-sm mb-1" onclick="return confirm('Delete this student?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function searchTable() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let rows = document.querySelectorAll("tbody tr");
        rows.forEach(row => {
            row.style.display = [...row.children].some(
            td => td.textContent.toLowerCase().includes(input)
            ) ? "" : "none";
        });
        }
    </script>
</body>
</html>

